public class TexxtMessageTester {
    public static void main(String[] args) {
        TextMessage textMessage = new TextMessage();
        textMessage.printDetails();
        //System.out.println(textMessage.getName());
        //System.out.println(textMessage.getSizeInKB());

        TextMessage textMessage1 = new TextMessage("Hello", "Jia", 10);
        textMessage1.printDetails();
       // System.out.println(textMessage1.getName());
       // System.out.println(textMessage1.getSizeInKB());

        TextMessageManager textMessageManager = new TextMessageManager();
        textMessageManager.processMessage(textMessage);
        textMessageManager.processMessage(textMessage);
        textMessageManager.processMessage(textMessage1);
        textMessageManager.processMessage(textMessage);

        TextMessageManager textMessageManager2 = new TextMessageManager(true,5);
        System.out.println(textMessageManager2.getMessageList());
        textMessageManager2.processMessageWithIndex(textMessage, 1);
        textMessageManager2.processMessageWithIndex(textMessage1, 3);
        System.out.println(textMessageManager2.getMessageList());

        TextMessageManager textMessageManager3 = new TextMessageManager();
        textMessageManager3.printAllMessages();
        textMessageManager.printAllMessages();

        System.out.println("---------------------------------------------");
        TextMessageManager textMessageManager4 = new TextMessageManager();
        textMessageManager4.processMessage(new TextMessage("Hello Supriya", "Supriya Biswas", 180));
        textMessageManager4.processMessage(new TextMessage("Supriya Hello", "Jia", 80));
        textMessageManager4.processMessage(new TextMessage("Hello Supriya", "Biswas Jia", 120));
        textMessageManager4.processMessage(new TextMessage("Hello Jia", "Supriya Jia", 10));
        textMessageManager4.searchMessage("Jia");
    }
}
