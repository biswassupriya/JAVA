import java.util.ArrayList;
import java.util.Arrays;

public class TextMessageManager {
    private ArrayList<TextMessage> messageList;

    public TextMessageManager() {
        this.messageList = new ArrayList();
    }

    public TextMessageManager(boolean initialize, int size) {
        if(initialize) {
            this.messageList = new ArrayList();
            for(int i=0; i<size; i++) {
                this.messageList.add(null);
            }
        } else {
            this.messageList = new ArrayList();
        }
    }

    public ArrayList getMessageList(){
        return this.messageList;
    }
    public void processMessage(TextMessage textMessage){
        if(messageList.contains(textMessage)) {
            System.out.println("This TextMessage object is already in your collection!");
        } else {
            messageList.add(textMessage);
            System.out.println("TextMessage object added successfully to your collection!");
        }
    }

    public void processMessageWithIndex(TextMessage textMessage, int index){
        if(messageList.contains(textMessage)) {
            System.out.println("This TextMessage object is already in your collection!");
        } else {
            messageList.add(index, textMessage);
            System.out.println("TextMessage object added successfully to your collection!");
        }
    }

    public boolean isMessageListBlank() {
        if(messageList.isEmpty()) {
            return true;
        } else {
            return false;
        }
    }

    public void printAllMessages() {
        if(messageList.isEmpty()) {
            System.out.println("Message list is empty");
        } else {
            for(int i=0; i<messageList.size(); i++) {
                System.out.println("At index " + i + " Message :" + messageList.get(i).printDetailsSingleLiner());

            }
        }
    }

    public void searchMessage(String searchString) {
        if(messageList.isEmpty()) {
            System.out.println("Message list is empty");
        } else {
            for(int i=0; i<messageList.size(); i++) {
                TextMessage localTextMessage = messageList.get(i);
                String localName = localTextMessage.getName();
                int localSizeInKb = localTextMessage.getSizeInKB();
                if(localName.startsWith(searchString) || localSizeInKb < 100) {
                    System.out.println("At index " + i + " Message :" + messageList.get(i).printDetailsSingleLiner());
                }
            }
        }
    }
}
