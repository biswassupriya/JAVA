public class TextMessage {
    private String message;
    private String name;
    private int sizeInKB;

    public TextMessage(){
        this.message = "I am learning java";
        this.name = "Supriya Biswas";
        this.sizeInKB = 1;
    }
     public TextMessage(String text, String fullName, int size){
         this.message = text;
         this.name = fullName;
         this.sizeInKB = size;
     }

     public void setMessage(String message){
        this.message = message;
     }

     public String getMessage(){
        return this.message;
     }

     public  void setName(String name){
        this.name = name;
     }

     public String getName(){
        return this.name;
     }
     public void setSizeInKB(int size){
        this.sizeInKB=size;
     }
     public int getSizeInKB(){
        return sizeInKB;
     }
     public void printDetails() {
         System.out.println(this.getMessage());
         System.out.println(this.getName());
         System.out.println(this.getSizeInKB());
     }

    public String printDetailsSingleLiner() {
         return "message=" + this.getMessage() + " name=" + this.getName() + " size=" + this.getSizeInKB();
    }
}
