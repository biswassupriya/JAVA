public class SavingsAccount extends BankAccount {
    private double Interestrate;

        public SavingsAccount(){
          double Interestrate =0.0;
    }
    public void setInterestrate(double interestrate){
            this.Interestrate = interestrate;
    }
    public double getInterestrate(){
            return Interestrate;
    }
    }

