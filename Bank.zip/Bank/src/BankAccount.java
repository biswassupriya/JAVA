public class BankAccount {

    private int accountNumber;
    private double Balance;


    public BankAccount(){
        int accountNumber = 0;
        double Balance = 0.0;
    }

    public int getAccountNumber() {//accessor method also known as getter method to access the variable outside the class
        return accountNumber;
    }

    public void setAccountNumber(int accountNumber) { //setter method is to update the data or variable
        this.accountNumber = accountNumber;
    }

    public void  setBalance(double balance){
        this.Balance = balance;
    }

    public double getBalance(){
        return Balance;
    }
}
