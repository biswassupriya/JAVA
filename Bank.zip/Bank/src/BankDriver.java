import java.util.ArrayList;

public class BankDriver extends BankAccount {
    private ArrayList<BankAccount> bankAccountArrayList = new ArrayList();
}
