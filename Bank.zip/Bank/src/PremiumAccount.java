public class PremiumAccount extends BankAccount {
    private int minimumbalance;
}
