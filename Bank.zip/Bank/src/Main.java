public class Main {
    public static void main(String[] args) {
       BankAccount Account = new BankAccount();

         Account.setAccountNumber(123456);
         Account.setBalance(50000.00);

       SavingsAccount Interest = new SavingsAccount();
        Interest.setInterestrate(20);
        Interest.setAccountNumber(123456);
        Interest.setBalance(5000.00);

      KidsAccount snigdha = new KidsAccount();
       snigdha.setBonus(1000);
       snigdha.setAccountNumber(56789);
       snigdha.setBalance(60000.00);

     System.out.println("The account number is:"+ Account.getAccountNumber()  +"The balance is: £" + Account.getBalance());
     System.out.println("The interest rate is:"+ Interest.getInterestrate() + "The Account number is:"+Interest.getAccountNumber() + "The Balance is:£" + Interest.getBalance());
     System.out.println("The Account number is:" + snigdha.getAccountNumber() + "The Bonus received is: £" + snigdha.getBonus() + "The Balance is:£" + snigdha.getBalance());
 }

}
