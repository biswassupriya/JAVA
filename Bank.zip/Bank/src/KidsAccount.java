public class KidsAccount extends BankAccount {
    private double Bonus;

    public KidsAccount(){
        double Bonus = 0.0;
    }
    public void setBonus(double bonus){
        this.Bonus = bonus;
    }
    public double getBonus(){
        return Bonus;
    }
}
