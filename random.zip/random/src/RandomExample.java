import java.util.Random;

public class RandomExample {

    public static void main(String[] args) {
        Random r = new Random();
        for (int i = 0; i < 25; i++) {
           // System.out.println("Value of i:"+ i);
            System.out.println(r.nextInt(7) + 1);
        }

    }

}
